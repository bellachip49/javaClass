class Parakeet {
    //no field

    //constructor
    Parakeet(){}

    //no getter or setter

    //other methods
    void printParakeetData(){
        System.out.println("Bird species is parakeet.");
        System.out.println("Parakeets enjoy eating fresh fruit.");
        System.out.println("Some parakeet favorites include apples, pears, melon, kiwi, berries, grapes and oranges.");
    }
}
