class IfClass {
    //constructor
    IfClass(){}
}
