class Canary {
    //no fields

    //constructor
    Canary(){}

    //no getter or setter

    //other methods
    void printCanaryData(){
        System.out.println("Bird species is canary.");
        System.out.println("They like to eat green beans, corn, cabbage, cauliflower, carrots and peas");
    }
}
