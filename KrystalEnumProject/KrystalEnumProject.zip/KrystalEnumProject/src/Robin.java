class Robin {
    //no field

    //constructor
    Robin(){}

    //no getter or setter

    //other methods
    void printRobinData(){
        System.out.println("Bird species is robin.");
        System.out.println("They are usually bright red in color.");
    }
}
