class Finch {
    //no field

    //constructor
    Finch(){}

    //no getter or setter

    //other methods
    void printFinchData(){
        System.out.println("Bird species is a finch.");
        System.out.println("Some people own finches as a pet.");
        System.out.println("They are generally seedeaters and eat a variety of plant seeds, especially grasses.");
    }
}
