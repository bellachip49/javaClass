class Chickadee {
    //field

    //constructor
    Chickadee(){}

    //no getter or setter

    //other methods
    void printChickadeeData(){
        System.out.println("Bird species is a chickadee.");
        System.out.println("Chickadees are smaller birds. They are found in North America.");
        System.out.println("They eat a diet of seeds, berries, insects, invertebrates, and occasionally small portions of carrion.");
    }
}

