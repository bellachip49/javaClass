public class Genesis2 {
    //fields
    private String otherString = "In the beginning ";

    //constructor
    public Genesis2(){

    }

    //getter
    public String getOtherString(){
        return otherString;
    }

    //setter
    public void setOtherString(String newotherString){
        this.otherString = newotherString;
    }
}
