public class Genesis1 {
    //fields
    private String myString = "In The Beginning ";

    //constructor
    public Genesis1(){

    }
    //methods
    //getter
    public String getMyString(){
        return myString;
    }
    //setter
    public void setMyString(String newMyString){
        this.myString = newMyString;
    }
}
