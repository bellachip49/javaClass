class AveOfArray {
    //no fields

    //constructor
    AveOfArray(){

    }

    //no getter or setter

    //other methods
    void arrayAvg(int sum, int [] givenArray){
        System.out.println("The average is " + (sum / givenArray.length) + ".");
    }
}
