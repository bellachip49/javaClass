public class PokemonRunner {
    public static void main(String [] args){
        Pikachu pikamon = new Pikachu();
        Charmander charmon = new Charmander();
        pikamon.curious();
        pikamon.PokeLang();
        charmon.approach();
        charmon.PokeLang();
    }
}
