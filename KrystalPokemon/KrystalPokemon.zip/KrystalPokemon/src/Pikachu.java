class Pikachu extends Monster {
    public void PokeLang(){
        System.out.println("It's a Pikachu.");
        System.out.println("\"Pika pii...\"");
    }
}
