class Charmander extends Monster{
    public void PokeLang(){
        System.out.println("It's a Charmander.");
        System.out.println("\"Char...!\"");
    }
}
