abstract class Monster {
    public abstract void PokeLang();
    public void curious(){
        System.out.println("A Pokemon stares at you, waiting for some Pokefood.");
    }
    public void approach(){
        System.out.println("A Pokemon approaches you and unties your shoelaces.");
    }
}
