class Tadpole implements Pond{
    public void fishing(){
        System.out.println("The fishing pole was cast! Fishing...");
    }
    public void caught(){
        System.out.println("\"I caught a tadpole! It's just a tad small.\"");
    }
}
