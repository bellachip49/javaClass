interface Pond {
    public void fishing();
    public void caught();
}
