class Koi implements Pond{
    public void fishing(){
        System.out.println("The fishing pole was cast! Fishing...");
    }
    public void caught(){
        System.out.println("\"I caught a koi! Don't be coy! (Ugh.)\"");
    }
}
